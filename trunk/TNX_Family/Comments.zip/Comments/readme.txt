
Ionize Comments Module -> Adding blog like comments capabilities to articles.

Author : 		Ionize Dev Team
Creation date : 	2011.04.10
Last update :		2011.04.15
Ionize version :	0.9.7

				
--------------------------------------------------------------------------------



Installation
---------------------------------------

1. Register the module through the Ionize Modules panel (click on "install")

2. To be done, full demo theme will be provided
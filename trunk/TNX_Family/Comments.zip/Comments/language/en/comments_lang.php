<?php

/*
|--------------------------------------------------------------------------
| Demo module Language file
|
| Language : 	English
| Tranlsator : 	Partikule Studio
|
| Notes : Modules translation items should begin with the prefix 'module_name'
|		  where 'module_name' is the name of the module
|
|--------------------------------------------------------------------------
*/

$lang['module_demo_settings_title'] = 'Module settings';
$lang['module_demo_settings_text'] = 'These settings are saved in the <var>/modules/Demo/config/config.php</var> file';
$lang['module_demo_setting_true_false'] = 'True / False setting';
$lang['module_demo_setting_string'] = 'String setting';

$lang['module_demo_database_title'] = 'Module Database settings';

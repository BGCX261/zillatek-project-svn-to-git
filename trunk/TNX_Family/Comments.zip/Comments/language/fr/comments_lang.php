<?php

/*
|--------------------------------------------------------------------------
| Test module Language file
|
| Language : 	Français
| Tranlsator : 	Partikule Studio
|
| Notes : Modules translation items should begin with the prefix 'module_name'
|		  where 'module_name' is the name of the module
|
|--------------------------------------------------------------------------
*/

$lang['module_search_button_start'] =			'Commencer la recherche';
$lang['module_search_message_no_results'] =		'Aucun résultat trouvé';
$lang['module_search_fill_the_field'] =			'Saisissez le terme recherché';
$lang['module_search_results_title'] =			'Résultats pour : ';

